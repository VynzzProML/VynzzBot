*/
// [❗] 
// [❗] NAMA AUTHOR "Nayla" 
// [❗] Nama Pemilik Bot "Vynzz"
const xxx = '```' 
exports.grupmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳  
│${tz} ${xxx}${prefix}hidetag${xxx}
│${tz} ${xxx}${prefix}add${xxx}
│${tz} ${xxx}${prefix}kick${xxx}
│${tz} ${xxx}${prefix}promote${xxx}
│${tz} ${xxx}${prefix}demote${xxx}
│${tz} ${xxx}${prefix}antilink${xxx}
│${tz} ${xxx}${prefix}welcome${xxx}
│${tz} ${xxx}${prefix}hidetag10${xxx}
│${tz} ${xxx}${prefix}group${xxx}
│${tz} ${xxx}${prefix}antigay${xxx}
│${tz} ${xxx}${prefix}antibocil${xxx}
│${tz} ${xxx}${prefix}antiwibu${xxx}
│${tz} ${xxx}${prefix}antikasar${xxx}
│${tz} ${xxx}${prefix}antitag${xxx}
│${tz} ${xxx}${prefix}level${xxx}
│${tz} ${xxx}${prefix}limit${xxx}
│${tz} ${xxx}${prefix}leveling${xxx}
│${tz} ${xxx}${prefix}antijawa${xxx} 
│${tz} ${xxx}${prefix}katajago${xxx}
│${tz} ${xxx}${prefix}linkgc${xxx}
│${tz} ${xxx}${prefix}tagall${xxx}
│${tz} ${xxx}${prefix}delete${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.stickmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳  
│${tz} ${xxx}${prefix}stickbucin${xxx}
│${tz} ${xxx}${prefix}stickanjing${xxx}
│${tz} ${xxx}${prefix}gawrgura${xxx}
│${tz} ${xxx}${prefix}umongus${xxx}
│${tz} ${xxx}${prefix}dadu${xxx}
│${tz} ${xxx}${prefix}randompatrick${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
│${tz} ${xxx}${prefix}sticker${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.promenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}nulis1${xxx}
│${tz} ${xxx}${prefix}nulis2${xxx}
│${tz} ${xxx}${prefix}nulis3${xxx}
│${tz} ${xxx}${prefix}nulis4${xxx}
│${tz} ${xxx}${prefix}nulis5${xxx}
│${tz} ${xxx}${prefix}nulis6${xxx}
│${tz} ${xxx}${prefix}video1${xxx}
│${tz} ${xxx}${prefix}video2${xxx}
│${tz} ${xxx}${prefix}video3${xxx}
│${tz} ${xxx}${prefix}video4${xxx}
│${tz} ${xxx}${prefix}video5${xxx}
│${tz} ${xxx}${prefix}video6${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.downloadmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}telesticker${xxx}
│${tz} ${xxx}${prefix}tiktokmusic${xxx}
│${tz} ${xxx}${prefix}tiktoknowm${xxx}
│${tz} ${xxx}${prefix}igfoto${xxx}
│${tz} ${xxx}${prefix}igvideo${xxx}
│${tz} ${xxx}${prefix}ytsearch${xxx}
│${tz} ${xxx}${prefix}ytmp3${xxx}
│${tz} ${xxx}${prefix}ytmp4${xxx}
│${tz} ${xxx}${prefix}play${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.soundmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}tomp3${xxx}
│${tz} ${xxx}${prefix}sound1${xxx}
│${tz} ${xxx}${prefix}sound2${xxx}
│${tz} ${xxx}${prefix}sound3${xxx}
│${tz} ${xxx}${prefix}sound4${xxx}
│${tz} ${xxx}${prefix}sound5${xxx}
│${tz} ${xxx}${prefix}sound6${xxx}
│${tz} ${xxx}${prefix}sound7${xxx}
│${tz} ${xxx}${prefix}sound8${xxx}
│${tz} ${xxx}${prefix}sound9${xxx}
│${tz} ${xxx}${prefix}sound10${xxx}
│${tz} ${xxx}${prefix}sound11${xxx}
│${tz} ${xxx}${prefix}sound12${xxx}
│${tz} ${xxx}${prefix}sound13${xxx}
│${tz} ${xxx}${prefix}sound14${xxx}
│${tz} ${xxx}${prefix}sound15${xxx}
│${tz} ${xxx}${prefix}sound16${xxx}
│${tz} ${xxx}${prefix}sound17${xxx}
│${tz} ${xxx}${prefix}sound18${xxx}
│${tz} ${xxx}${prefix}sound19${xxx}
│${tz} ${xxx}${prefix}sound20${xxx}
│${tz} ${xxx}${prefix}sound21${xxx}
│${tz} ${xxx}${prefix}sound22${xxx}
│${tz} ${xxx}${prefix}sound23${xxx}
│${tz} ${xxx}${prefix}sound24${xxx}
│${tz} ${xxx}${prefix}sound25${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.pornmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}indo1${xxx} 
│${tz} ${xxx}${prefix}indo2${xxx} 
│${tz} ${xxx}${prefix}indo3${xxx} 
│${tz} ${xxx}${prefix}indo4${xxx} 
│${tz} ${xxx}${prefix}indo5${xxx} 
│${tz} ${xxx}${prefix}indo6${xxx} 
│${tz} ${xxx}${prefix}indo7${xxx} 
│${tz} ${xxx}${prefix}indo8${xxx} 
│${tz} ${xxx}${prefix}indo9${xxx} 
│${tz} ${xxx}${prefix}indo10${xxx} 
│${tz} ${xxx}${prefix}indo11${xxx} 
│${tz} ${xxx}${prefix}indo12${xxx} 
│${tz} ${xxx}${prefix}indo13${xxx} 
│${tz} ${xxx}${prefix}indo14${xxx} 
│${tz} ${xxx}${prefix}indo15${xxx} 
│${tz} ${xxx}${prefix}indo16${xxx} 
│${tz} ${xxx}${prefix}indo17${xxx} 
│${tz} ${xxx}${prefix}indo18${xxx} 
│${tz} ${xxx}${prefix}indo19${xxx} 
│${tz} ${xxx}${prefix}indo20${xxx} 
│${tz} ${xxx}${prefix}indo21${xxx} 
│${tz} ${xxx}${prefix}indo22${xxx} 
│${tz} ${xxx}${prefix}indo23${xxx} 
│${tz} ${xxx}${prefix}indo24${xxx} 
│${tz} ${xxx}${prefix}indo25${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.internalmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}readmore${xxx}
│${tz} ${xxx}${prefix}chatlist${xxx}
│${tz} ${xxx}${prefix}addsticker${xxx}
│${tz} ${xxx}${prefix}addvn${xxx}
│${tz} ${xxx}${prefix}getvn${xxx}
│${tz} ${xxx}${prefix}getsticker${xxx}
│${tz} ${xxx}${prefix}liststicker${xxx}
│${tz} ${xxx}${prefix}listvn${xxx}
│${tz} ${xxx}${prefix}addimage${xxx}
│${tz} ${xxx}${prefix}getimage${xxx}
│${tz} ${xxx}${prefix}imagelist${xxx}
│${tz} ${xxx}${prefix}addvideo${xxx}
│${tz} ${xxx}${prefix}getvideo${xxx}
│${tz} ${xxx}${prefix}listvideo${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.cekmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}gantengcek${xxx}
│${tz} ${xxx}${prefix}cantikcek${xxx}
│${tz} ${xxx}${prefix}jelekcek${xxx}
│${tz} ${xxx}${prefix}goblokcek${xxx}
│${tz} ${xxx}${prefix}begocek${xxx}
│${tz} ${xxx}${prefix}pintercek${xxx}
│${tz} ${xxx}${prefix}jagocek${xxx}
│${tz} ${xxx}${prefix}nolepcek${xxx}
│${tz} ${xxx}${prefix}babicek${xxx}
│${tz} ${xxx}${prefix}bebancek${xxx}
│${tz} ${xxx}${prefix}baikcek${xxx}
│${tz} ${xxx}${prefix}jahatcek${xxx}
│${tz} ${xxx}${prefix}anjingcek${xxx}
│${tz} ${xxx}${prefix}haramcek${xxx}
│${tz} ${xxx}${prefix}kontolcek${xxx}
│${tz} ${xxx}${prefix}pakboycek${xxx}
│${tz} ${xxx}${prefix}pakgirlcek${xxx}
│${tz} ${xxx}${prefix}sangecek${xxx}
│${tz} ${xxx}${prefix}bapercek${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.tagmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}ganteng${xxx}
│${tz} ${xxx}${prefix}cantik${xxx}
│${tz} ${xxx}${prefix}jelek${xxx}
│${tz} ${xxx}${prefix}goblok${xxx}
│${tz} ${xxx}${prefix}bego${xxx}
│${tz} ${xxx}${prefix}pinter${xxx}
│${tz} ${xxx}${prefix}jago${xxx}
│${tz} ${xxx}${prefix}babi${xxx}
│${tz} ${xxx}${prefix}beban${xxx}
│${tz} ${xxx}${prefix}baik${xxx}
│${tz} ${xxx}${prefix}jahat${xxx}
│${tz} ${xxx}${prefix}anjing${xxx}
│${tz} ${xxx}${prefix}monyet${xxx}
│${tz} ${xxx}${prefix}haram${xxx}
│${tz} ${xxx}${prefix}kontol${xxx}
│${tz} ${xxx}${prefix}pakboy${xxx}
│${tz} ${xxx}${prefix}pakgirl${xxx}
│${tz} ${xxx}${prefix}sadboy${xxx}
│${tz} ${xxx}${prefix}sadgirl${xxx}
│${tz} ${xxx}${prefix}wibu${xxx}
│${tz} ${xxx}${prefix}nolep${xxx}
│${tz} ${xxx}${prefix}hebat${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.gamemenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}slot${xxx}
│${tz} ${xxx}${prefix}simi${xxx}
│${tz} ${xxx}${prefix}jumlah${xxx}
│${tz} ${xxx}${prefix}hurufkebalik${xxx}
│${tz} ${xxx}${prefix}tebakgambar${xxx}
│${tz} ${xxx}${prefix}nickff${xxx}
│${tz} ${xxx}${prefix}kapankah${xxx}
│${tz} ${xxx}${prefix}apakah${xxx}
│${tz} ${xxx}${prefix}ramalnomer${xxx} 
│${tz} ${xxx}${prefix}ramalcinta${xxx} 
│${tz} ${xxx}${prefix}jodohbali${xxx} 
│${tz} ${xxx}${prefix}ramalnikah${xxx} 
│${tz} ${xxx}${prefix}taksirmimpi${xxx} 
│${tz} ${xxx}${prefix}suit${xxx}                   
│${tz} ${xxx}${prefix}boomtext${xxx}
│${tz} ${xxx}${prefix}holoh${xxx}
│${tz} ${xxx}${prefix}heleh${xxx}
│${tz} ${xxx}${prefix}huluh${xxx}
│${tz} ${xxx}${prefix}hilih${xxx}
│${tz} ${xxx}${prefix}halah${xxx} 
│${tz} ${xxx}${prefix}kapital${xxx}
│${tz} ${xxx}${prefix}textfont${xxx}
│${tz} ${xxx}${prefix}tebak${xxx}
│${tz} ${xxx}${prefix}oxo${xxx}
│${tz} ${xxx}${prefix}pesan${xxx}
│${tz} ${xxx}${prefix}tebakkimia${xxx}
│${tz} ${xxx}${prefix}tebaklirik${xxx}
│${tz} ${xxx}${prefix}tebakin1${xxx}
│${tz} ${xxx}${prefix}tebakin2${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.randomtext = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}quotes2${xxx}
│${tz} ${xxx}${prefix}grubwa${xxx}
│${tz} ${xxx}${prefix}brainly${xxx}
│${tz} ${xxx}${prefix}quotes1${xxx}
│${tz} ${xxx}${prefix}kusonime${xxx}
│${tz} ${xxx}${prefix}renungan${xxx}
│${tz} ${xxx}${prefix}samehadaku${xxx}
│${tz} ${xxx}${prefix}infonomer${xxx}
│${tz} ${xxx}${prefix}jadwaltv${xxx}
│${tz} ${xxx}${prefix}tvjadwal${xxx}
│${tz} ${xxx}${prefix}fml${xxx}
│${tz} ${xxx}${prefix}cinta${xxx}
│${tz} ${xxx}${prefix}resepmasakan${xxx}
│${tz} ${xxx}${prefix}cersex${xxx}
│${tz} ${xxx}${prefix}cerpen${xxx}
│${tz} ${xxx}${prefix}jadwalsholat${xxx}
│${tz} ${xxx}${prefix}pantun${xxx}
│${tz} ${xxx}${prefix}cuaca${xxx}
│${tz} ${xxx}${prefix}namaninja${xxx}
│${tz} ${xxx}${prefix}fake${xxx}
│${tz} ${xxx}${prefix}spamcall${xxx}
│${tz} ${xxx}${prefix}spamemail${xxx}
│${tz} ${xxx}${prefix}quotes${xxx}
│${tz} ${xxx}${prefix}quotesnime${xxx}
│${tz} ${xxx}${prefix}kbbilazimedia${xxx}
│${tz} ${xxx}${prefix}covid${xxx}
│${tz} ${xxx}${prefix}wikiid${xxx}
│${tz} ${xxx}${prefix}wikien${xxx}
│${tz} ${xxx}${prefix}covidid${xxx}
│${tz} ${xxx}${prefix}kbbi${xxx}
│${tz} ${xxx}${prefix}infogempa${xxx}
│${tz} ${xxx}${prefix}randomquran${xxx}
│${tz} ${xxx}${prefix}kisanabi${xxx}
│${tz} ${xxx}${prefix}artinama${xxx}
│${tz} ${xxx}${prefix}artimimpi${xxx}
│${tz} ${xxx}${prefix}artijadian${xxx}
│${tz} ${xxx}${prefix}chord${xxx}
│${tz} ${xxx}${prefix}lirik${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.fastmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}fb${xxx}
│${tz} ${xxx}${prefix}tts${xxx}
│${tz} ${xxx}${prefix}steam${xxx}
│${tz} ${xxx}${prefix}stalktwit${xxx}
│${tz} ${xxx}${prefix}stalkgithub${xxx} 
│${tz} ${xxx}${prefix}randomhusbu${xxx}
│${tz} ${xxx}${prefix}pinterest${xxx}
│${tz} ${xxx}${prefix}randomwaifu${xxx}
│${tz} ${xxx}${prefix}randomwaifu1${xxx}
│${tz} ${xxx}${prefix}stalkig${xxx}
│${tz} ${xxx}${prefix}estetikpic${xxx}
│${tz} ${xxx}${prefix}memeindo${xxx}
│${tz} ${xxx}${prefix}darkjokes${xxx}
│${tz} ${xxx}${prefix}urlshort${xxx}
│${tz} ${xxx}${prefix}shortener${xxx}
│${tz} ${xxx}${prefix}fox${xxx}
│${tz} ${xxx}${prefix}dog${xxx}
│${tz} ${xxx}${prefix}cat${xxx}
│${tz} ${xxx}${prefix}panda${xxx}
│${tz} ${xxx}${prefix}panda1${xxx}
│${tz} ${xxx}${prefix}bird${xxx}
│${tz} ${xxx}${prefix}koala${xxx}
│${tz} ${xxx}${prefix}meme${xxx}  
│${tz} ${xxx}${prefix}asupan${xxx}
│${tz} ${xxx}${prefix}asupan1${xxx}
│${tz} ${xxx}${prefix}asupan2${xxx}
│${tz} ${xxx}${prefix}ngakak${xxx}
│${tz} ${xxx}${prefix}pin${xxx} 
│${tz} ${xxx}${prefix}foto${xxx} 
│${tz} ${xxx}${prefix}bts${xxx}
│${tz} ${xxx}${prefix}exo${xxx}
│${tz} ${xxx}${prefix}blackpink${xxx}
│${tz} ${xxx}${prefix}attp${xxx}
│${tz} ${xxx}${prefix}manga1${xxx}
│${tz} ${xxx}${prefix}character${xxx}
│${tz} ${xxx}${prefix}ttp4${xxx}
│${tz} ${xxx}${prefix}ttp3${xxx}
│${tz} ${xxx}${prefix}ttp2${xxx}
│${tz} ${xxx}${prefix}ttp1${xxx}
│${tz} ${xxx}${prefix}sticker${xxx}
│${tz} ${xxx}${prefix}stickergif${xxx}
│${tz} ${xxx}${prefix}bug${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.sertifikat = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}ffserti${xxx} 
│${tz} ${xxx}${prefix}ffserti2${xxx}
│${tz} ${xxx}${prefix}ffserti3${xxx}
│${tz} ${xxx}${prefix}ffserti4${xxx}
│${tz} ${xxx}${prefix}ffserti5${xxx}
│${tz} ${xxx}${prefix}pubgserti${xxx}
│${tz} ${xxx}${prefix}pubgserti2${xxx}
│${tz} ${xxx}${prefix}pubgserti3${xxx}
│${tz} ${xxx}${prefix}pubgserti4${xxx}
│${tz} ${xxx}${prefix}pubgserti5${xxx}
│${tz} ${xxx}${prefix}mlserti${xxx}
│${tz} ${xxx}${prefix}mlserti2${xxx}
│${tz} ${xxx}${prefix}mlserti3${xxx}
│${tz} ${xxx}${prefix}mlserti4${xxx}
│${tz} ${xxx}${prefix}mlserti5${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.ownermenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}dellprem${xxx} 
│${tz} ${xxx}${prefix}addprem${xxx}
│${tz} ${xxx}${prefix}clearall${xxx}
│${tz} ${xxx}${prefix}bc${xxx}
│${tz} ${xxx}${prefix}owner${xxx}
│${tz} ${xxx}${prefix}author${xxx}
│${tz} ${xxx}${prefix}bugtroli${xxx}
│${tz} ${xxx}${prefix}setout${xxx}
│${tz} ${xxx}${prefix}setwelcome${xxx}
│${tz} ${xxx}${prefix}settz${xxx}
│${tz} ${xxx}${prefix}setthum${xxx}
│${tz} ${xxx}${prefix}setpp${xxx}
│${tz} ${xxx}${prefix}setprefix${xxx}
│${tz} ${xxx}${prefix}setreply${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.makerfoto = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}crossgun${xxx} 
│${tz} ${xxx}${prefix}bakar${xxx}
│${tz} ${xxx}${prefix}pensil${xxx}
│${tz} ${xxx}${prefix}pantaimalam${xxx}
│${tz} ${xxx}${prefix}costumwp${xxx}
│${tz} ${xxx}${prefix}facebookpage${xxx}
│${tz} ${xxx}${prefix}gtav${xxx}
│${tz} ${xxx}${prefix}deteksiumur${xxx}
│${tz} ${xxx}${prefix}removebg${xxx}
│${tz} ${xxx}${prefix}deteksiwajah${xxx}
│${tz} ${xxx}${prefix}wanted${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.spesialmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}randomwibu${xxx}
│${tz} ${xxx}${prefix}phkomen${xxx}
│${tz} ${xxx}${prefix}semoji${xxx}
│${tz} ${xxx}${prefix}jadian${xxx}
│${tz} ${xxx}${prefix}citacita${xxx}
│${tz} ${xxx}${prefix}laut${xxx}
│${tz} ${xxx}${prefix}darat${xxx}
│${tz} ${xxx}${prefix}udara${xxx}
│${tz} ${xxx}${prefix}fakta${xxx}
│${tz} ${xxx}${prefix}gcard${xxx}
│${tz} ${xxx}${prefix}ssweb${xxx}
│${tz} ${xxx}${prefix}katailham${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.menuZ = (ownername, auth0r, bulan, tchat, tz, prefix) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}OWNER : ${ownername}${xxx}
│${tz} ${xxx}AUTHOR : ${auth0r}${xxx}
│${tz} ${xxx}BULAN : ${bulan}${xxx}
│${tz} ${xxx}CHAT : ${tchat}${xxx}
╰──❲ 2011 ❳
╭──❲ ${xxx}PERATURAN${xxx} ❳
│${tz} ${xxx}JGN SPAM FITUR BOT${xxx}
│${tz} ${xxx}JGN CALL BOT INI${xxx}
│${tz} ${xxx}JGN TOXIC KE BOT${xxx}
│${tz} ${xxx}JGN PLAGIAT BOT${xxx}
│${tz} ${xxx}JGN CULIK BOT INI${xxx}
│${tz} ${xxx}JGN MEMBANDING BOT${xxx}
╰──❲ ${xxx}2021${xxx} ❳
╭──❲ ${xxx}LISTMENU${xxx} ❳
│${tz} ${xxx}${prefix}ownermenu${xxx}
│${tz} ${xxx}${prefix}grupmenu${xxx} 
│${tz} ${xxx}${prefix}promenu${xxx}
│${tz} ${xxx}${prefix}downloadmenu${xxx}
│${tz} ${xxx}${prefix}soundmenu${xxx}
│${tz} ${xxx}${prefix}pornmenu${xxx}
│${tz} ${xxx}${prefix}internalmenu${xxx}
│${tz} ${xxx}${prefix}cekmenu${xxx}
│${tz} ${xxx}${prefix}spesialmenu${xxx}
│${tz} ${xxx}${prefix}tagmenu${xxx}
│${tz} ${xxx}${prefix}gamemenu${xxx}
│${tz} ${xxx}${prefix}randomtext${xxx}
│${tz} ${xxx}${prefix}fastmenu${xxx}
│${tz} ${xxx}${prefix}sertifikat${xxx}
│${tz} ${xxx}${prefix}makerfoto${xxx}
│${tz} ${xxx}${prefix}stickmenu${xxx}
│${tz} ${xxx}${prefix}newsmenu${xxx}
╰──❲ ${xxx}2021${xxx} ❳
╭──❲ ${xxx}LISTMENU${xxx} ❳
│${tz} ${xxx}${prefix}allmenu${xxx}
│${tz} ${xxx}${prefix}mygrub${xxx}
│${tz} ${xxx}${prefix}request${xxx}
╰──❲ ${xxx}BOTZ.6.1.2${xxx} ❳
╭──❲ ${xxx}THX TO${xxx} ❳
│${tz} ${xxx}ALL CREATOR BOT${xxx}
│${tz} ${xxx}NAYLACHAN${xxx}
│${tz} ${xxx}RYNZ${xxx}
│${tz} ${xxx}LOLI KILLERS${xxx}
│${tz} ${xxx}ARA-ARA${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.botx = (prefix) => {
	return`[❗] MODE BOT MATI TLOL\nKETIK *${prefix}botx*\nUNTUK MENGAKTIFKAN`
	}
exports.prem1 = (command) => { 
    return`MAAF TPI FITUR *${command}* KHUSUS MEMBER AF`
    }
exports.error = (prefix, command) => {
    return`[❗] ERROR SILAHKAN LAPORKAN KE OWNER. KETIK *${prefix}bug ${command}*\n[ *APIKEY UNFALID* ]`
    }
exports.info1 = () => { 
    return`🐳 = $200
🦈 = $121
🐬 = $104
🐋 = $94
🐟 = $87
🐠 = $79
🦐 = $62
🦑 = $34
🦀 = $17
🐚 = $2
*NOTE* : TETAPLAH BERBURU WAHAI BEBAN KELUARGA`
  }
exports.info2 = () => { 
    return`🐔 = $200
🦃 = $121
🐿 = $104
🐐 = $94
🐏 = $87
🐖 = $79
🐑 = $62
🐎 = $34
🐺 = $17
🦩 = $2
*NOTE* : TETAPLAH BERBURU WAHAI BEBAN KELUARGA`
}
exports.info3 = () => { 
    return`🦋 = $200
🕷 = $121
🐝 = $104
🐉 = $94
🦆 = $87
🦅 = $79
🕊 = $62
🐧 = $34
🐦 = $17
🦇 = $2
*NOTE* : TETAPLAH BERBURU WAHAI BEBAN KELUARGA`
} 
exports.lvlnul = () => {
	return`*LEVELMU MASIH KECIL*`
}
exports.nayzelite = (pushname, prefix) => { 
    return`╭──❲ ${xxx}NOT ELITE${xxx} ❳ 
│${tz} ${xxx}NAMA : ${pushname}${xxx}
│${tz} ${xxx}KAMU BUKAN ELITE${xxx}
│${tz} ${xxx}KETIK ${prefix}elitebot${xxx}
│${tz} ${xxx}UNTUK BERGABUNG${xxx}
╰──❲ ${xxx}BOTZ V.6.1.2${xxx} ❳`
}
exports.elitenay = (pushname, prefix) => { 
    return`╭──❲ ${xxx}SUKSES${xxx} ❳
│${tz} ${xxx}NAMA : ${pushname}${xxx}
│${tz} ${xxx}SILAHKAN KETIK ${prefix}menu${xxx}
│${tz} ${xxx}INFO BOT? KETIK ${prefix}info${xxx}
│${tz} ${xxx}OTHER?? KETIK ${prefix}other${xxx}
╰──❲ ${xxx}BOTZ V.6.1.2${xxx} ❳`	
}
exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel) => {
	return`╭──❲ ${xxx}NAIK LEVEL${xxx} ❳
│${tz} ${xxx}Nama : ${pushname}${xxx}
│${tz} ${xxx}wa.me/${sender.split("@")[0]}${xxx}
│${tz} ${xxx}Xp : ${getLevelingXp(sender)}${xxx}
│${tz} ${xxx}Limit : +3${xxx} 
│${tz} ${xxx}Level : ${getLevel} ⊱ ${getLevelingLevel(sender)}${xxx}
╰──❲ ${xxx}BOTZ V.6.1.2${xxx} ❳`	
}
exports.allmenu = (ownername, auth0r, bulan, tchat, tz, prefix) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}OWNER : ${ownername}${xxx}
│${tz} ${xxx}AUTHOR : ${auth0r}${xxx}
│${tz} ${xxx}BULAN : ${bulan}${xxx}
│${tz} ${xxx}CHAT : ${tchat}${xxx}
╰──❲ 2011 ❳
╭──❲ ${xxx}PERATURAN${xxx} ❳
│${tz} ${xxx}JGN SPAM FITUR BOT${xxx}
│${tz} ${xxx}JGN CALL BOT INI${xxx}
│${tz} ${xxx}JGN TOXIC KE BOT${xxx}
│${tz} ${xxx}JGN PLAGIAT BOT${xxx}
│${tz} ${xxx}JGN CULIK BOT INI${xxx}
│${tz} ${xxx}JGN MEMBANDING BOT${xxx}
╰──❲ ${xxx}2021${xxx} ❳
╭──❲ ${xxx}ALL MENU BOT${xxx} ❳
│${tz} ${xxx}${prefix}hidetag${xxx}
│${tz} ${xxx}${prefix}add${xxx}
│${tz} ${xxx}${prefix}kick${xxx}
│${tz} ${xxx}${prefix}promote${xxx}
│${tz} ${xxx}${prefix}demote${xxx}
│${tz} ${xxx}${prefix}antilink${xxx}
│${tz} ${xxx}${prefix}welcome${xxx}
│${tz} ${xxx}${prefix}level${xxx}
│${tz} ${xxx}${prefix}limit${xxx}
│${tz} ${xxx}${prefix}leveling${xxx}
│${tz} ${xxx}${prefix}hidetag10${xxx}
│${tz} ${xxx}${prefix}group${xxx}
│${tz} ${xxx}${prefix}antigay${xxx}
│${tz} ${xxx}${prefix}antibocil${xxx}
│${tz} ${xxx}${prefix}antiwibu${xxx}
│${tz} ${xxx}${prefix}antikasar${xxx}
│${tz} ${xxx}${prefix}antitag${xxx}
│${tz} ${xxx}${prefix}antijawa${xxx} 
│${tz} ${xxx}${prefix}katajago${xxx}
│${tz} ${xxx}${prefix}linkgc${xxx}
│${tz} ${xxx}${prefix}tagall${xxx}
│${tz} ${xxx}${prefix}delete${xxx}
│${tz} ${xxx}${prefix}stickbucin${xxx}
│${tz} ${xxx}${prefix}stickanjing${xxx}
│${tz} ${xxx}${prefix}gawrgura${xxx}
│${tz} ${xxx}${prefix}umongus${xxx}
│${tz} ${xxx}${prefix}dadu${xxx}
│${tz} ${xxx}${prefix}randompatrick${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
│${tz} ${xxx}${prefix}sticker${xxx}
│${tz} ${xxx}${prefix}wallteknologi${xxx}
│${tz} ${xxx}${prefix}wallhacker${xxx}
│${tz} ${xxx}${prefix}wallcyber${xxx}
│${tz} ${xxx}${prefix}wallmuslim${xxx}
│${tz} ${xxx}${prefix}wallpegunungan${xxx}
│${tz} ${xxx}${prefix}caklontong${xxx}
│${tz} ${xxx}${prefix}robot${xxx}
│${tz} ${xxx}${prefix}3dwhite${xxx}
│${tz} ${xxx}${prefix}daun${xxx}
│${tz} ${xxx}${prefix}metal1${xxx}
│${tz} ${xxx}${prefix}metal${xxx}
│${tz} ${xxx}${prefix}scary${xxx}
│${tz} ${xxx}${prefix}imo${xxx}
│${tz} ${xxx}${prefix}wallpaper${xxx}
│${tz} ${xxx}${prefix}tahta${xxx}
│${tz} ${xxx}${prefix}neon2${xxx}
│${tz} ${xxx}${prefix}wall${xxx}
│${tz} ${xxx}${prefix}wolf${xxx}
│${tz} ${xxx}${prefix}tfire${xxx}
│${tz} ${xxx}${prefix}ytgold${xxx}
│${tz} ${xxx}${prefix}ytsilver${xxx}
│${tz} ${xxx}${prefix}t3d${xxx}
│${tz} ${xxx}${prefix}logoa${xxx}
│${tz} ${xxx}${prefix}pornhub${xxx}
│${tz} ${xxx}${prefix}marvel${xxx}
│${tz} ${xxx}${prefix}leavest${xxx}
│${tz} ${xxx}${prefix}phcoment${xxx}
│${tz} ${xxx}${prefix}nulis${xxx}
│${tz} ${xxx}${prefix}neon1${xxx}
│${tz} ${xxx}${prefix}text3d${xxx}
│${tz} ${xxx}${prefix}galaxy${xxx}
│${tz} ${xxx}${prefix}gaming${xxx}
│${tz} ${xxx}${prefix}colors${xxx}
│${tz} ${xxx}${prefix}kling${xxx}
│${tz} ${xxx}${prefix}barcode${xxx}
│${tz} ${xxx}${prefix}qrcode${xxx}
│${tz} ${xxx}${prefix}8bit${xxx}
│${tz} ${xxx}${prefix}burn${xxx}
│${tz} ${xxx}${prefix}fire${xxx}
│${tz} ${xxx}${prefix}google${xxx}
│${tz} ${xxx}${prefix}battle${xxx}
│${tz} ${xxx}${prefix}block${xxx}
│${tz} ${xxx}${prefix}candy${xxx}
│${tz} ${xxx}${prefix}potter${xxx}
│${tz} ${xxx}${prefix}silk${xxx}
│${tz} ${xxx}${prefix}water${xxx}
│${tz} ${xxx}${prefix}pubg${xxx}
│${tz} ${xxx}${prefix}neon${xxx}
│${tz} ${xxx}${prefix}coffe1${xxx}
│${tz} ${xxx}${prefix}coffe${xxx}
│${tz} ${xxx}${prefix}tiktok${xxx}
│${tz} ${xxx}${prefix}shadow${xxx}
│${tz} ${xxx}${prefix}romance${xxx}
│${tz} ${xxx}${prefix}glass${xxx}
│${tz} ${xxx}${prefix}naruto${xxx}
│${tz} ${xxx}${prefix}mug1${xxx}
│${tz} ${xxx}${prefix}love${xxx}
│${tz} ${xxx}${prefix}mug${xxx}
│${tz} ${xxx}${prefix}neon1${xxx}
│${tz} ${xxx}${prefix}smoke${xxx}
│${tz} ${xxx}${prefix}rainbow${xxx}
│${tz} ${xxx}${prefix}nulis1${xxx}
│${tz} ${xxx}${prefix}nulis2${xxx}
│${tz} ${xxx}${prefix}nulis3${xxx}
│${tz} ${xxx}${prefix}nulis4${xxx}
│${tz} ${xxx}${prefix}nulis5${xxx}
│${tz} ${xxx}${prefix}nulis6${xxx}
│${tz} ${xxx}${prefix}video1${xxx}
│${tz} ${xxx}${prefix}video2${xxx}
│${tz} ${xxx}${prefix}video3${xxx}
│${tz} ${xxx}${prefix}video4${xxx}
│${tz} ${xxx}${prefix}video5${xxx}
│${tz} ${xxx}${prefix}video6${xxx}
│${tz} ${xxx}${prefix}telesticker${xxx}
│${tz} ${xxx}${prefix}tiktokmusic${xxx}
│${tz} ${xxx}${prefix}tiktoknowm${xxx}
│${tz} ${xxx}${prefix}igfoto${xxx}
│${tz} ${xxx}${prefix}igvideo${xxx}
│${tz} ${xxx}${prefix}ytsearch${xxx}
│${tz} ${xxx}${prefix}ytmp3${xxx}
│${tz} ${xxx}${prefix}ytmp4${xxx}
│${tz} ${xxx}${prefix}play${xxx}
│${tz} ${xxx}${prefix}sound1${xxx}
│${tz} ${xxx}${prefix}sound2${xxx}
│${tz} ${xxx}${prefix}sound3${xxx}
│${tz} ${xxx}${prefix}sound4${xxx}
│${tz} ${xxx}${prefix}sound5${xxx}
│${tz} ${xxx}${prefix}sound6${xxx}
│${tz} ${xxx}${prefix}sound7${xxx}
│${tz} ${xxx}${prefix}sound8${xxx}
│${tz} ${xxx}${prefix}sound9${xxx}
│${tz} ${xxx}${prefix}sound10${xxx}
│${tz} ${xxx}${prefix}sound11${xxx}
│${tz} ${xxx}${prefix}sound12${xxx}
│${tz} ${xxx}${prefix}sound13${xxx}
│${tz} ${xxx}${prefix}sound14${xxx}
│${tz} ${xxx}${prefix}sound15${xxx}
│${tz} ${xxx}${prefix}sound16${xxx}
│${tz} ${xxx}${prefix}sound17${xxx}
│${tz} ${xxx}${prefix}sound18${xxx}
│${tz} ${xxx}${prefix}sound19${xxx}
│${tz} ${xxx}${prefix}sound20${xxx}
│${tz} ${xxx}${prefix}sound21${xxx}
│${tz} ${xxx}${prefix}sound22${xxx}
│${tz} ${xxx}${prefix}sound23${xxx}
│${tz} ${xxx}${prefix}sound24${xxx}
│${tz} ${xxx}${prefix}sound25${xxx}
│${tz} ${xxx}${prefix}indo1${xxx} 
│${tz} ${xxx}${prefix}indo2${xxx} 
│${tz} ${xxx}${prefix}indo3${xxx} 
│${tz} ${xxx}${prefix}indo4${xxx} 
│${tz} ${xxx}${prefix}indo5${xxx} 
│${tz} ${xxx}${prefix}indo6${xxx} 
│${tz} ${xxx}${prefix}indo7${xxx} 
│${tz} ${xxx}${prefix}indo8${xxx} 
│${tz} ${xxx}${prefix}indo9${xxx} 
│${tz} ${xxx}${prefix}indo10${xxx} 
│${tz} ${xxx}${prefix}indo11${xxx} 
│${tz} ${xxx}${prefix}indo12${xxx} 
│${tz} ${xxx}${prefix}indo13${xxx} 
│${tz} ${xxx}${prefix}indo14${xxx} 
│${tz} ${xxx}${prefix}indo15${xxx} 
│${tz} ${xxx}${prefix}indo16${xxx} 
│${tz} ${xxx}${prefix}indo17${xxx} 
│${tz} ${xxx}${prefix}indo18${xxx} 
│${tz} ${xxx}${prefix}indo19${xxx} 
│${tz} ${xxx}${prefix}indo20${xxx} 
│${tz} ${xxx}${prefix}indo21${xxx} 
│${tz} ${xxx}${prefix}indo22${xxx} 
│${tz} ${xxx}${prefix}indo23${xxx} 
│${tz} ${xxx}${prefix}indo24${xxx} 
│${tz} ${xxx}${prefix}indo25${xxx}
│${tz} ${xxx}${prefix}readmore${xxx}
│${tz} ${xxx}${prefix}chatlist${xxx}
│${tz} ${xxx}${prefix}addsticker${xxx}
│${tz} ${xxx}${prefix}addvn${xxx}
│${tz} ${xxx}${prefix}getvn${xxx}
│${tz} ${xxx}${prefix}getsticker${xxx}
│${tz} ${xxx}${prefix}liststicker${xxx}
│${tz} ${xxx}${prefix}listvn${xxx}
│${tz} ${xxx}${prefix}addimage${xxx}
│${tz} ${xxx}${prefix}getimage${xxx}
│${tz} ${xxx}${prefix}imagelist${xxx}
│${tz} ${xxx}${prefix}addvideo${xxx}
│${tz} ${xxx}${prefix}getvideo${xxx}
│${tz} ${xxx}${prefix}listvideo${xxx}
│${tz} ${xxx}${prefix}gantengcek${xxx}
│${tz} ${xxx}${prefix}cantikcek${xxx}
│${tz} ${xxx}${prefix}jelekcek${xxx}
│${tz} ${xxx}${prefix}goblokcek${xxx}
│${tz} ${xxx}${prefix}begocek${xxx}
│${tz} ${xxx}${prefix}pintercek${xxx}
│${tz} ${xxx}${prefix}jagocek${xxx}
│${tz} ${xxx}${prefix}nolepcek${xxx}
│${tz} ${xxx}${prefix}babicek${xxx}
│${tz} ${xxx}${prefix}bebancek${xxx}
│${tz} ${xxx}${prefix}baikcek${xxx}
│${tz} ${xxx}${prefix}jahatcek${xxx}
│${tz} ${xxx}${prefix}anjingcek${xxx}
│${tz} ${xxx}${prefix}haramcek${xxx}
│${tz} ${xxx}${prefix}kontolcek${xxx}
│${tz} ${xxx}${prefix}pakboycek${xxx}
│${tz} ${xxx}${prefix}pakgirlcek${xxx}
│${tz} ${xxx}${prefix}sangecek${xxx}
│${tz} ${xxx}${prefix}bapercek${xxx}
│${tz} ${xxx}${prefix}ganteng${xxx}
│${tz} ${xxx}${prefix}cantik${xxx}
│${tz} ${xxx}${prefix}jelek${xxx}
│${tz} ${xxx}${prefix}goblok${xxx}
│${tz} ${xxx}${prefix}bego${xxx}
│${tz} ${xxx}${prefix}pinter${xxx}
│${tz} ${xxx}${prefix}jago${xxx}
│${tz} ${xxx}${prefix}babi${xxx}
│${tz} ${xxx}${prefix}beban${xxx}
│${tz} ${xxx}${prefix}baik${xxx}
│${tz} ${xxx}${prefix}jahat${xxx}
│${tz} ${xxx}${prefix}anjing${xxx}
│${tz} ${xxx}${prefix}monyet${xxx}
│${tz} ${xxx}${prefix}haram${xxx}
│${tz} ${xxx}${prefix}kontol${xxx}
│${tz} ${xxx}${prefix}pakboy${xxx}
│${tz} ${xxx}${prefix}pakgirl${xxx}
│${tz} ${xxx}${prefix}sadboy${xxx}
│${tz} ${xxx}${prefix}sadgirl${xxx}
│${tz} ${xxx}${prefix}wibu${xxx}
│${tz} ${xxx}${prefix}nolep${xxx}
│${tz} ${xxx}${prefix}hebat${xxx}
│${tz} ${xxx}${prefix}slot${xxx}
│${tz} ${xxx}${prefix}simi${xxx}
│${tz} ${xxx}${prefix}jumlah${xxx}
│${tz} ${xxx}${prefix}hurufkebalik${xxx}
│${tz} ${xxx}${prefix}tebakgambar${xxx}
│${tz} ${xxx}${prefix}nickff${xxx}
│${tz} ${xxx}${prefix}kapankah${xxx}
│${tz} ${xxx}${prefix}apakah${xxx}
│${tz} ${xxx}${prefix}ramalnomer${xxx} 
│${tz} ${xxx}${prefix}ramalcinta${xxx} 
│${tz} ${xxx}${prefix}jodohbali${xxx} 
│${tz} ${xxx}${prefix}ramalnikah${xxx} 
│${tz} ${xxx}${prefix}taksirmimpi${xxx} 
│${tz} ${xxx}${prefix}suit${xxx}                   
│${tz} ${xxx}${prefix}boomtext${xxx}
│${tz} ${xxx}${prefix}holoh${xxx}
│${tz} ${xxx}${prefix}heleh${xxx}
│${tz} ${xxx}${prefix}huluh${xxx}
│${tz} ${xxx}${prefix}hilih${xxx}
│${tz} ${xxx}${prefix}halah${xxx} 
│${tz} ${xxx}${prefix}kapital${xxx}
│${tz} ${xxx}${prefix}textfont${xxx}
│${tz} ${xxx}${prefix}tebak${xxx}
│${tz} ${xxx}${prefix}oxo${xxx}
│${tz} ${xxx}${prefix}pesan${xxx}
│${tz} ${xxx}${prefix}tebakkimia${xxx}
│${tz} ${xxx}${prefix}tebaklirik${xxx}
│${tz} ${xxx}${prefix}tebakin1${xxx}
│${tz} ${xxx}${prefix}tebakin2${xxx}
│${tz} ${xxx}${prefix}quotes2${xxx}
│${tz} ${xxx}${prefix}quotes1${xxx}
│${tz} ${xxx}${prefix}kusonime${xxx}
│${tz} ${xxx}${prefix}renungan${xxx}
│${tz} ${xxx}${prefix}samehadaku${xxx}
│${tz} ${xxx}${prefix}infonomer${xxx}
│${tz} ${xxx}${prefix}jadwaltv${xxx}
│${tz} ${xxx}${prefix}tvjadwal${xxx}
│${tz} ${xxx}${prefix}fml${xxx}
│${tz} ${xxx}${prefix}cinta${xxx}
│${tz} ${xxx}${prefix}resepmasakan${xxx}
│${tz} ${xxx}${prefix}cersex${xxx}
│${tz} ${xxx}${prefix}cerpen${xxx}
│${tz} ${xxx}${prefix}jadwalsholat${xxx}
│${tz} ${xxx}${prefix}pantun${xxx}
│${tz} ${xxx}${prefix}cuaca${xxx}
│${tz} ${xxx}${prefix}namaninja${xxx}
│${tz} ${xxx}${prefix}fake${xxx}
│${tz} ${xxx}${prefix}spamcall${xxx}
│${tz} ${xxx}${prefix}spamemail${xxx}
│${tz} ${xxx}${prefix}quotes${xxx}
│${tz} ${xxx}${prefix}quotesnime${xxx}
│${tz} ${xxx}${prefix}kbbilazimedia${xxx}
│${tz} ${xxx}${prefix}covid${xxx}
│${tz} ${xxx}${prefix}wikiid${xxx}
│${tz} ${xxx}${prefix}wikien${xxx}
│${tz} ${xxx}${prefix}covidid${xxx}
│${tz} ${xxx}${prefix}kbbi${xxx}
│${tz} ${xxx}${prefix}infogempa${xxx}
│${tz} ${xxx}${prefix}randomquran${xxx}
│${tz} ${xxx}${prefix}kisanabi${xxx}
│${tz} ${xxx}${prefix}artinama${xxx}
│${tz} ${xxx}${prefix}artimimpi${xxx}
│${tz} ${xxx}${prefix}artijadian${xxx}
│${tz} ${xxx}${prefix}chord${xxx}
│${tz} ${xxx}${prefix}lirik${xxx}
│${tz} ${xxx}${prefix}fb${xxx}
│${tz} ${xxx}${prefix}tts${xxx}
│${tz} ${xxx}${prefix}steam${xxx}
│${tz} ${xxx}${prefix}stalktwit${xxx}
│${tz} ${xxx}${prefix}stalkgithub${xxx} 
│${tz} ${xxx}${prefix}randomhusbu${xxx}
│${tz} ${xxx}${prefix}pinterest${xxx}
│${tz} ${xxx}${prefix}randomwaifu${xxx}
│${tz} ${xxx}${prefix}randomwaifu1${xxx}
│${tz} ${xxx}${prefix}stalkig${xxx}
│${tz} ${xxx}${prefix}estetikpic${xxx}
│${tz} ${xxx}${prefix}memeindo${xxx}
│${tz} ${xxx}${prefix}darkjokes${xxx}
│${tz} ${xxx}${prefix}urlshort${xxx}
│${tz} ${xxx}${prefix}shortener${xxx}
│${tz} ${xxx}${prefix}fox${xxx}
│${tz} ${xxx}${prefix}dog${xxx}
│${tz} ${xxx}${prefix}cat${xxx}
│${tz} ${xxx}${prefix}panda${xxx}
│${tz} ${xxx}${prefix}panda1${xxx}
│${tz} ${xxx}${prefix}bird${xxx}
│${tz} ${xxx}${prefix}koala${xxx}
│${tz} ${xxx}${prefix}meme${xxx}  
│${tz} ${xxx}${prefix}asupan${xxx}
│${tz} ${xxx}${prefix}asupan1${xxx}
│${tz} ${xxx}${prefix}asupan2${xxx}
│${tz} ${xxx}${prefix}ngakak${xxx}
│${tz} ${xxx}${prefix}pin${xxx} 
│${tz} ${xxx}${prefix}foto${xxx} 
│${tz} ${xxx}${prefix}bts${xxx}
│${tz} ${xxx}${prefix}exo${xxx}
│${tz} ${xxx}${prefix}blackpink${xxx}
│${tz} ${xxx}${prefix}attp${xxx}
│${tz} ${xxx}${prefix}manga1${xxx}
│${tz} ${xxx}${prefix}character${xxx}
│${tz} ${xxx}${prefix}ttp4${xxx}
│${tz} ${xxx}${prefix}ttp3${xxx}
│${tz} ${xxx}${prefix}ttp2${xxx}
│${tz} ${xxx}${prefix}ttp1${xxx}
│${tz} ${xxx}${prefix}sticker${xxx}
│${tz} ${xxx}${prefix}stickergif${xxx}
│${tz} ${xxx}${prefix}bug${xxx}
│${tz} ${xxx}${prefix}ffserti${xxx} 
│${tz} ${xxx}${prefix}ffserti2${xxx}
│${tz} ${xxx}${prefix}ffserti3${xxx}
│${tz} ${xxx}${prefix}ffserti4${xxx}
│${tz} ${xxx}${prefix}ffserti5${xxx}
│${tz} ${xxx}${prefix}pubgserti${xxx}
│${tz} ${xxx}${prefix}pubgserti2${xxx}
│${tz} ${xxx}${prefix}pubgserti3${xxx}
│${tz} ${xxx}${prefix}pubgserti4${xxx}
│${tz} ${xxx}${prefix}pubgserti5${xxx}
│${tz} ${xxx}${prefix}mlserti${xxx}
│${tz} ${xxx}${prefix}mlserti2${xxx}
│${tz} ${xxx}${prefix}mlserti3${xxx}
│${tz} ${xxx}${prefix}mlserti4${xxx}
│${tz} ${xxx}${prefix}mlserti5${xxx}
│${tz} ${xxx}${prefix}dellprem${xxx} 
│${tz} ${xxx}${prefix}addprem${xxx}
│${tz} ${xxx}${prefix}clearall${xxx}
│${tz} ${xxx}${prefix}bc${xxx}
│${tz} ${xxx}${prefix}owner${xxx}
│${tz} ${xxx}${prefix}author${xxx}
│${tz} ${xxx}${prefix}bugtroli${xxx}
│${tz} ${xxx}${prefix}setout${xxx}
│${tz} ${xxx}${prefix}setwelcome${xxx}
│${tz} ${xxx}${prefix}settz${xxx}
│${tz} ${xxx}${prefix}setthum${xxx}
│${tz} ${xxx}${prefix}setpp${xxx}
│${tz} ${xxx}${prefix}setprefix${xxx}
│${tz} ${xxx}${prefix}setreply${xxx}
│${tz} ${xxx}${prefix}crossgun${xxx} 
│${tz} ${xxx}${prefix}bakar${xxx}
│${tz} ${xxx}${prefix}pensil${xxx}
│${tz} ${xxx}${prefix}pantaimalam${xxx}
│${tz} ${xxx}${prefix}costumwp${xxx}
│${tz} ${xxx}${prefix}facebookpage${xxx}
│${tz} ${xxx}${prefix}gtav${xxx}
│${tz} ${xxx}${prefix}deteksiumur${xxx}
│${tz} ${xxx}${prefix}removebg${xxx}
│${tz} ${xxx}${prefix}deteksiwajah${xxx}
│${tz} ${xxx}${prefix}wanted${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
│${tz} ${xxx}${prefix}phkomen${xxx}
│${tz} ${xxx}${prefix}semoji${xxx}
│${tz} ${xxx}${prefix}jadian${xxx}
│${tz} ${xxx}${prefix}citacita${xxx}
│${tz} ${xxx}${prefix}laut${xxx}
│${tz} ${xxx}${prefix}darat${xxx}
│${tz} ${xxx}${prefix}udara${xxx}
│${tz} ${xxx}${prefix}fakta${xxx}
│${tz} ${xxx}${prefix}gcard${xxx}
│${tz} ${xxx}${prefix}ssweb${xxx}
│${tz} ${xxx}${prefix}katailham${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
╰──❲ ${xxx}2021${xxx} ❳
╭──❲ ${xxx}THX TO${xxx} ❳
│${tz} ${xxx}ALL CREATOR BOT${xxx}
│${tz} ${xxx}NAYLACHAN${xxx}
│${tz} ${xxx}RYNZ${xxx}
│${tz} ${xxx}LOLI KILLERS${xxx}
│${tz} ${xxx}ARA-ARA${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}
exports.newsmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}WHATSAPP${xxx} ❳
│${tz} ${xxx}${prefix}newsdetik${xxx}
│${tz} ${xxx}${prefix}newskompas${xxx}
│${tz} ${xxx}${prefix}newskompas${xxx}
│${tz} ${xxx}${prefix}newstribun${xxx}
│${tz} ${xxx}${prefix}jalantikus${xxx}
╰──❲ ${xxx}BY ${ownername}${xxx} ❳`
}