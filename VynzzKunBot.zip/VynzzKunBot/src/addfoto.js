const addfoto = () => { 
	return `
	
	*ADD DATABASE FOTO*
	
      Foto Berhasil Disimpan Tod!
	

Makasih Wibu !`
}
exports.addfoto = addfoto